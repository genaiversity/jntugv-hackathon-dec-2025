
from fastapi import FastAPI
from pydantic import BaseModel
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB

app = FastAPI()

class SMS(BaseModel):
    message: str

spam_keywords = ["free", "win", "recharge", "offer", "click", "urgent"]
vectorizer = TfidfVectorizer()
model = MultinomialNB()

# Dummy training data (replace with Kaggle dataset)
X = ["free recharge now", "hello how are you", "win cash prize", "let us meet"]
y = [1, 0, 1, 0]

X_vec = vectorizer.fit_transform(X)
model.fit(X_vec, y)

@app.post("/predict")
def predict(sms: SMS):
    msg = sms.message.lower()
    if re.search(r"http|www", msg):
        return {"label": "spam", "confidence": 0.99}

    vec = vectorizer.transform([msg])
    prob = model.predict_proba(vec)[0]
    label = "spam" if prob[1] > 0.5 else "ham"
    return {"label": label, "confidence": round(float(max(prob)), 2)}
