
async function classifySMS() {
    const sms = document.getElementById("sms").value;
    const response = await fetch("http://localhost:8000/predict", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({message: sms})
    });
    const data = await response.json();
    document.getElementById("result").innerText =
        `Prediction: ${data.label} (Confidence: ${data.confidence})`;
}
