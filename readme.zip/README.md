
# SMS Spam Filter (Telco Messaging)

## Overview
This project classifies SMS messages as **Spam** or **Ham** for a telecom messaging gateway.

## Features
- Tokenization + TF-IDF
- Naive Bayes baseline model
- Regex-based URL and telco-offer detection
- Simple frontend UI
- REST API backend

## Tech Stack
- Python, FastAPI
- scikit-learn
- Regex rules
- HTML/CSS/JavaScript

## How to Run

### Backend
```bash
pip install -r requirements.txt
uvicorn app:app --reload
```

### Frontend
Open `index.html` in a browser.

## Dataset
Use SMS Spam Collection Dataset from Kaggle:
https://www.kaggle.com/uciml/sms-spam-collection-dataset
